/* ===========================================================
   Conteúdo do site — edite aqui os textos sem mexer no código.
   =========================================================== */

const SERVICOS = [
  {
    icon:"🐶", titulo:"Consulta Domiciliar",
    resumo:"Avaliação clínica completa no conforto da sua casa.",
    detalhe:"Uma consulta tranquila, sem o estresse do transporte. A Dra. Esther faz a avaliação clínica do seu pet, escuta o histórico, esclarece dúvidas e orienta o melhor caminho de cuidado — tudo no ambiente em que o animal se sente seguro."
  },
  {
    icon:"💉", titulo:"Vacinação",
    resumo:"Vacinas essenciais aplicadas em casa, com calma.",
    detalhe:"Aplicação de vacinas com toda a segurança e sem filas. Orientamos o calendário vacinal ideal para a idade e o estilo de vida do seu pet, mantendo a carteirinha sempre em dia."
  },
  {
    icon:"🩸", titulo:"Coleta de Exames",
    resumo:"Coleta de material para exames sem deslocamento.",
    detalhe:"Coletamos o material necessário para exames laboratoriais na sua casa, reduzindo o estresse do animal. Os resultados orientam diagnósticos precisos e acompanhamento de tratamentos."
  },
  {
    icon:"🐾", titulo:"Check-up Preventivo",
    resumo:"Prevenir é cuidar antes de o problema aparecer.",
    detalhe:"Uma avaliação preventiva periódica ajuda a identificar sinais precoces e a manter a saúde em dia. Ideal para todas as idades, especialmente para pets que não gostam de sair de casa."
  },
  {
    icon:"🐱", titulo:"Atendimento Geriátrico",
    resumo:"Cuidado especial para pets na melhor idade.",
    detalhe:"Pets idosos merecem atenção redobrada e o mínimo de estresse. O atendimento em casa é ideal para acompanhar de perto a qualidade de vida, com manejo cuidadoso e carinhoso."
  },
  {
    icon:"🤍", titulo:"Cuidados Paliativos",
    resumo:"Conforto, dignidade e amor em todos os momentos.",
    detalhe:"Acompanhamento dedicado para garantir bem-estar e qualidade de vida nos momentos mais delicados, com respeito ao pet e acolhimento à família, sempre no ambiente familiar."
  },
  {
    icon:"📋", titulo:"Atestados e Documentos",
    resumo:"Documentação veterinária com validade e cuidado.",
    detalhe:"Emissão de atestados de saúde, declarações e demais documentações veterinárias necessárias, com a avaliação adequada e atenção a cada detalhe."
  },
  {
    icon:"🚑", titulo:"Orientações Emergenciais",
    resumo:"Orientação rápida para saber o próximo passo.",
    detalhe:"Em situações de urgência, oferecemos orientação para os primeiros cuidados e indicação do encaminhamento mais seguro. Fale conosco para avaliarmos juntos a melhor conduta."
  }
];

const DEPOIMENTOS = [
  { texto:"Atendimento maravilhoso! Meu cachorro ficou muito mais tranquilo sendo atendido em casa. A Dra. Esther tem um carinho enorme.", autor:"Camila R.", pet:"Tutora do Thor", cor:"#0C4A56" },
  { texto:"Minha gata é super arisca e nunca aceitou ir à clínica. Em casa foi outra história — atendimento calmo e cuidadoso do início ao fim.", autor:"Rafael M.", pet:"Tutor da Mel", cor:"#C6A15B" },
  { texto:"Profissional atenciosa e humana de verdade. Explicou tudo com paciência e meu pet nem percebeu a vacina. Recomendo de olhos fechados!", autor:"Patrícia L.", pet:"Tutora do Bento", cor:"#7FCDBF" },
  { texto:"Cuidou do meu idoso de 14 anos com um respeito que me emocionou. Saber que ele foi cuidado em casa fez toda a diferença para nós.", autor:"João P.", pet:"Tutor da Nina", cor:"#1B2A47" },
  { texto:"Praticidade e carinho na mesma visita. Agendei pelo WhatsApp e em pouco tempo estava tudo resolvido sem estresse nenhum.", autor:"Aline S.", pet:"Tutora do Caramelo", cor:"#0C4A56" }
];

const BLOG = [
  { cat:"Vacinas", titulo:"Calendário de vacinas: quando vacinar seu pet", resumo:"Entenda as principais vacinas e em que idade cada uma deve ser aplicada para manter a proteção em dia." },
  { cat:"Cuidados Preventivos", titulo:"Check-up: por que prevenir é o melhor remédio", resumo:"Avaliações periódicas ajudam a flagrar problemas cedo. Saiba com que frequência levar a saúde a sério." },
  { cat:"Gatos", titulo:"Gato estressado no transporte? Existe solução", resumo:"Felinos sofrem muito fora de casa. Veja como o atendimento domiciliar transforma a experiência." },
  { cat:"Comportamento Animal", titulo:"Sinais de que algo não vai bem com seu pet", resumo:"Mudanças de apetite, sono e humor podem dizer muito. Aprenda a observar o que importa." },
  { cat:"Cães", titulo:"Cães idosos: cuidados na melhor idade", resumo:"Adaptações simples de rotina e acompanhamento garantem mais conforto e qualidade de vida." },
  { cat:"Saúde Animal", titulo:"Quando uma orientação emergencial faz diferença", resumo:"Saber o primeiro passo em uma urgência pode salvar vidas. Veja o que ter sempre em mente." }
];

const BLOG_CATS = ["Todos","Saúde Animal","Vacinas","Cuidados Preventivos","Comportamento Animal","Gatos","Cães"];
