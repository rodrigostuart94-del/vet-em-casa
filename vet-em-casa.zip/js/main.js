/* ===========================================================
   VET EM CASA — interatividade
   =========================================================== */
(function () {
  "use strict";

  // -------- Config central (edite aqui) --------
  const CONFIG = {
    whatsapp: "5521995472564",
    msgPadrao: "Olá! Gostaria de agendar um atendimento veterinário domiciliar.",
    fuso: -3 // America/Sao_Paulo (UTC-3) para Google Agenda
  };

  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => [...c.querySelectorAll(s)];
  const waLink = (msg) =>
    `https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent(msg || CONFIG.msgPadrao)}`;

  document.documentElement.classList.add("js");

  /* ---------- Ano no rodapé ---------- */
  $("#year").textContent = new Date().getFullYear();

  /* ---------- Links de WhatsApp ---------- */
  $$("[data-whats]").forEach((el) => {
    el.setAttribute("href", waLink(el.dataset.msg));
    el.setAttribute("target", "_blank");
    el.setAttribute("rel", "noopener");
  });

  /* ---------- Tema claro/escuro ---------- */
  const root = document.documentElement;
  const themeBtn = $("#theme-toggle");
  const saved = (() => { try { return localStorage.getItem("vetemcasa-theme"); } catch (e) { return null; } })();
  const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
  if (saved === "dark" || (!saved && prefersDark)) root.setAttribute("data-theme", "dark");
  themeBtn.addEventListener("click", () => {
    const dark = root.getAttribute("data-theme") === "dark";
    if (dark) root.removeAttribute("data-theme"); else root.setAttribute("data-theme", "dark");
    try { localStorage.setItem("vetemcasa-theme", dark ? "light" : "dark"); } catch (e) {}
  });

  /* ---------- Header scrolled + scroll spy ---------- */
  const header = $(".site-header");
  const navLinks = $$(".nav a");
  const sections = navLinks
    .map((a) => $(a.getAttribute("href")))
    .filter(Boolean);
  const onScroll = () => {
    header.classList.toggle("scrolled", window.scrollY > 12);
    let current = "";
    const y = window.scrollY + 140;
    sections.forEach((sec) => { if (sec.offsetTop <= y) current = "#" + sec.id; });
    navLinks.forEach((a) => a.classList.toggle("active", a.getAttribute("href") === current));
  };
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  /* ---------- Menu mobile ---------- */
  const navToggle = $("#nav-toggle");
  const nav = $("#nav-menu");
  const backdrop = $("#nav-backdrop");
  const setMenu = (open) => {
    nav.classList.toggle("open", open);
    navToggle.setAttribute("aria-expanded", String(open));
    backdrop.hidden = !open;
    document.body.style.overflow = open ? "hidden" : "";
  };
  navToggle.addEventListener("click", () => setMenu(!nav.classList.contains("open")));
  backdrop.addEventListener("click", () => setMenu(false));
  nav.addEventListener("click", (e) => { if (e.target.tagName === "A") setMenu(false); });

  /* ---------- Placeholders de foto (SVG de marca) ---------- */
  function brandPlaceholder(label) {
    const svg = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 800 800'>
      <defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'>
        <stop offset='0' stop-color='%231B2A47'/><stop offset='1' stop-color='%230C4A56'/></linearGradient></defs>
      <rect width='800' height='800' fill='url(%23g)'/>
      <g fill='%23C6A15B' opacity='0.85' transform='translate(400 360)'>
        <ellipse cx='-70' cy='-60' rx='34' ry='46'/><ellipse cx='-12' cy='-92' rx='34' ry='50'/>
        <ellipse cx='52' cy='-70' rx='32' ry='44'/><ellipse cx='0' cy='40' rx='84' ry='68'/>
      </g>
      <text x='400' y='560' fill='%23E4C98A' font-family='Georgia,serif' font-size='34' text-anchor='middle' opacity='0.92'>${label || "Vet em Casa"}</text>
    </svg>`;
    return "data:image/svg+xml," + svg.replace(/\n\s*/g, "");
  }
  $$(".ph").forEach((img) => {
    const ph = brandPlaceholder(img.dataset.label);
    img.addEventListener("error", () => { img.src = ph; }, { once: true });
    // Sem src real definido → mostra placeholder de marca
    if (!img.getAttribute("src")) img.src = ph;
  });

  /* ---------- Serviços (cards + modal) ---------- */
  const grid = $("#servicos-grid");
  grid.innerHTML = SERVICOS.map((s, i) => `
    <button class="card reveal" data-serv="${i}" type="button" style="transition-delay:${(i % 4) * 70}ms">
      <span class="card-ico">${s.icon}</span>
      <h3>${s.titulo}</h3>
      <p>${s.resumo}</p>
      <span class="card-more">Ver detalhes →</span>
    </button>`).join("");

  // Select de serviços na agenda
  const servSelect = $("#b-servico");
  servSelect.innerHTML = `<option value="">Selecione um serviço…</option>` +
    SERVICOS.map((s) => `<option>${s.titulo}</option>`).join("");

  /* ---------- Modal ---------- */
  const modal = $("#modal");
  let lastFocus = null;
  function openModal({ ico, titulo, body }) {
    $("#modal-ico").textContent = ico || "";
    $("#modal-title").textContent = titulo;
    $("#modal-body").innerHTML = body;
    $("#modal-cta").setAttribute("href", waLink(`Olá! Tenho interesse no serviço: ${titulo}.`));
    lastFocus = document.activeElement;
    modal.hidden = false;
    document.body.style.overflow = "hidden";
    $(".modal-close").focus();
  }
  function closeModal() {
    modal.hidden = true;
    document.body.style.overflow = "";
    if (lastFocus) lastFocus.focus();
  }
  grid.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-serv]");
    if (!btn) return;
    const s = SERVICOS[+btn.dataset.serv];
    openModal({ ico: s.icon, titulo: s.titulo, body: `<p>${s.detalhe}</p>` });
  });
  modal.addEventListener("click", (e) => { if (e.target.matches("[data-close]")) closeModal(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !modal.hidden) closeModal(); });

  // Modais institucionais (privacidade / termos)
  const INSTIT = {
    privacidade: {
      titulo: "Política de Privacidade", ico: "🔒",
      body: `<p>Este site não coleta nem armazena dados pessoais em servidores. As informações preenchidas no formulário de agendamento são usadas apenas para montar a sua mensagem de WhatsApp, enviada por você mesmo.</p>
             <p>Ao entrar em contato, seus dados são tratados com confidencialidade e usados somente para o atendimento veterinário solicitado.</p>`
    },
    termos: {
      titulo: "Termos de Uso", ico: "📄",
      body: `<p>As informações deste site têm caráter informativo e não substituem uma consulta veterinária presencial. O agendamento é confirmado diretamente pelo WhatsApp.</p>
             <p>Orientações emergenciais aqui descritas não substituem atendimento de urgência. Em caso de risco, procure um pronto atendimento veterinário.</p>`
    }
  };
  $$("[data-modal]").forEach((el) => el.addEventListener("click", (e) => {
    e.preventDefault();
    openModal(INSTIT[el.dataset.modal]);
  }));

  /* ---------- Depoimentos (carrossel) ---------- */
  const track = $("#reviews-track");
  const dots = $("#reviews-dots");
  track.innerHTML = DEPOIMENTOS.map((d) => `
    <div class="review">
      <div class="review-inner">
        <div class="stars" aria-label="5 de 5 estrelas">★★★★★</div>
        <p class="review-text">“${d.texto}”</p>
        <div class="review-author">
          <span class="review-avatar" style="background:${d.cor}">🐾</span>
          <span class="review-meta"><strong>${d.autor}</strong><span>${d.pet}</span></span>
        </div>
      </div>
    </div>`).join("");
  dots.innerHTML = DEPOIMENTOS.map((_, i) =>
    `<button type="button" role="tab" aria-label="Depoimento ${i + 1}"></button>`).join("");
  const dotEls = $$("button", dots);
  let idx = 0, timer;
  function go(i) {
    idx = (i + DEPOIMENTOS.length) % DEPOIMENTOS.length;
    track.style.transform = `translateX(-${idx * 100}%)`;
    dotEls.forEach((d, k) => d.classList.toggle("active", k === idx));
  }
  function auto() { clearInterval(timer); timer = setInterval(() => go(idx + 1), 5500); }
  dotEls.forEach((d, i) => d.addEventListener("click", () => { go(i); auto(); }));
  go(0); auto();
  $("#reviews").addEventListener("mouseenter", () => clearInterval(timer));
  $("#reviews").addEventListener("mouseleave", auto);

  /* ---------- Blog (filtro por categoria) ---------- */
  const cats = $("#blog-cats");
  const blogGrid = $("#blog-grid");
  cats.innerHTML = BLOG_CATS.map((c, i) =>
    `<button type="button" class="${i === 0 ? "active" : ""}" data-cat="${c}">${c}</button>`).join("");
  function renderBlog(cat) {
    const list = cat === "Todos" ? BLOG : BLOG.filter((p) => p.cat === cat);
    blogGrid.innerHTML = (list.length ? list : BLOG).map((p) => `
      <article class="post reveal">
        <div class="post-img"><span class="post-cat">${p.cat}</span></div>
        <div class="post-body">
          <h3>${p.titulo}</h3>
          <p>${p.resumo}</p>
          <a class="post-link" data-whats data-msg="Olá! Gostaria de saber mais sobre: ${p.titulo}" href="#" target="_blank" rel="noopener">Ler mais →</a>
        </div>
      </article>`).join("");
    // reaplica links de whats nos novos posts
    $$("[data-whats]", blogGrid).forEach((el) => {
      el.setAttribute("href", waLink(el.dataset.msg));
    });
    revealObserve($$(".reveal", blogGrid));
  }
  cats.addEventListener("click", (e) => {
    const b = e.target.closest("[data-cat]");
    if (!b) return;
    $$("button", cats).forEach((x) => x.classList.remove("active"));
    b.classList.add("active");
    renderBlog(b.dataset.cat);
  });
  renderBlog("Todos");

  /* ---------- Agenda online → WhatsApp + Google Agenda ---------- */
  const form = $("#booking-form");
  const errBox = $("#form-error");
  const gcal = $("#gcal-link");
  // data mínima = hoje
  const today = new Date().toISOString().split("T")[0];
  $("#b-data").min = today;

  function pad(n) { return String(n).padStart(2, "0"); }
  function gcalDates(dateStr, timeStr) {
    // dateStr: yyyy-mm-dd, timeStr: HH:MM (horário local Teresópolis)
    const [y, m, d] = dateStr.split("-").map(Number);
    const [hh, mm] = timeStr.split(":").map(Number);
    // converte para UTC somando o deslocamento (UTC-3 → +3h)
    const start = new Date(Date.UTC(y, m - 1, d, hh - CONFIG.fuso, mm));
    const end = new Date(start.getTime() + 60 * 60 * 1000);
    const fmt = (dt) => `${dt.getUTCFullYear()}${pad(dt.getUTCMonth() + 1)}${pad(dt.getUTCDate())}T${pad(dt.getUTCHours())}${pad(dt.getUTCMinutes())}00Z`;
    return `${fmt(start)}/${fmt(end)}`;
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    const obrig = [["servico", "b-servico"], ["data", "b-data"], ["hora", "b-hora"], ["tutor", "b-tutor"], ["pet", "b-pet"], ["especie", "b-especie"]];
    let firstInvalid = null;
    obrig.forEach(([k, id]) => {
      const el = $("#" + id);
      const empty = !String(data[k] || "").trim();
      el.classList.toggle("invalid", empty);
      if (empty && !firstInvalid) firstInvalid = el;
    });
    if (firstInvalid) {
      errBox.hidden = false;
      errBox.textContent = "Por favor, preencha os campos destacados para continuar.";
      firstInvalid.focus();
      return;
    }
    errBox.hidden = true;

    const dataBr = data.data.split("-").reverse().join("/");
    const msg =
`🐾 *Novo agendamento — Vet em Casa*

*Serviço:* ${data.servico}
*Data:* ${dataBr}
*Horário:* ${data.hora}
*Tutor(a):* ${data.tutor}${data.fone ? `\n*Telefone:* ${data.fone}` : ""}
*Pet:* ${data.pet} (${data.especie})${data.obs ? `\n*Observações:* ${data.obs}` : ""}

Aguardo a confirmação. Obrigado(a)! 🤍`;

    window.open(waLink(msg), "_blank", "noopener");

    // Botão Google Agenda
    const det = `Atendimento veterinário domiciliar — ${data.servico}. Pet: ${data.pet} (${data.especie}). Tutor(a): ${data.tutor}.`;
    const gurl = "https://calendar.google.com/calendar/render?action=TEMPLATE"
      + "&text=" + encodeURIComponent(`Vet em Casa — ${data.servico} (${data.pet})`)
      + "&dates=" + gcalDates(data.data, data.hora)
      + "&details=" + encodeURIComponent(det)
      + "&location=" + encodeURIComponent("Teresópolis e Região, RJ");
    gcal.setAttribute("href", gurl);
    gcal.hidden = false;
  });

  // limpa estado inválido ao digitar
  $$("#booking-form input, #booking-form select, #booking-form textarea").forEach((el) =>
    el.addEventListener("input", () => el.classList.remove("invalid")));

  /* ---------- Reveal on scroll ---------- */
  let io;
  function revealObserve(els) {
    if (!("IntersectionObserver" in window)) { els.forEach((el) => el.classList.add("in")); return; }
    if (!io) io = new IntersectionObserver((entries) => {
      entries.forEach((en) => { if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); } });
    }, { threshold: 0.12 });
    els.forEach((el) => io.observe(el));
  }
  // marca elementos para revelar
  $$(".section h2, .sec-lead, .values, .t-card, .compare-col, .area-map, .booking, .contact-card, .sobre-media")
    .forEach((el) => el.classList.add("reveal"));
  revealObserve($$(".reveal"));

  /* ---------- PWA: registro do service worker ---------- */
  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("sw.js").catch(() => {});
    });
  }
})();
